function out = Fsolve_1D_fcn(in)
x = in;
out = -x^3 - 2*x^2 + 50*x + 60;
end

