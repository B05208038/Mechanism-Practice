clear all

% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
% Plot to function
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 

% x is an array from -10 to 10 with interval 0.001
x = -10:0.001:10; 

% f is a function of x
f = -x.^3 - 2*x.^2 + 50*x + 60; 

% plot 1) the function f, and 2) y=0
figure;
plot(x,f,x,zeros(1,length(x)),'-.')
legend('y = -x^3 - 2x^2 + 50x + 60','y = 0')

% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
% Newton-Raphson Method
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 

x0 = -14; % inital guess of x, you can try different value 

for i = 1:10000 % loop for iteration
    % apply x0 to x(1) for the first iteration
    if i == 1
        x(i) = x0;
    end    
    y(i) = -x(i)^3 - 2*x(i)^2 + 50*x(i) + 60;
    if abs(y(i))<1e-4 % set the allowed error for y, if it meets the requirement then leave the loop
        break; 
    end
    % df(i) is the differentiation of y at x(i)
    df(i) = -3*x(i)^2 - 4*x(i) + 50;
    x(i+1) = -y(i)/df(i) + x(i);    
end

x_sol = x(i)