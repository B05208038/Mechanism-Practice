function out = Fsolve_2D_fcn(in)

a = in(1);
b = in(2);
f1 = a^2 + 2*b + 1;
f2 = a - b^3 - 5;
out = [f1 f2];

end

