clear all
x0 = 2;
x = fsolve(@Fsolve_1D_fcn,x0)