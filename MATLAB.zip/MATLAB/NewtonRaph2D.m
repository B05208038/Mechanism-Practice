% Newton-Raphson Method to solve the link angles of a four-bar linkage
clear all
th1 = 0; % theta1 = 0;
th2 = 0:0.001:2*pi; % theta2: from 0 to 2*pi, interval:0.001 rad

R1 = 12; 
R2 = 4;
R3 = 8;
R4 = 11;

% initial guess of theta3 and theta4
th30 = -100*pi/180;
th40 = 30*pi/180;

for i = 1:length(th2)   % loop for different theta2
    for j = 1:10000 % loop for iteration
        if j == 1
            th3t(j) = th30; % assign the initial guess value 
            th4t(j) = th40;
        end
        
        if th3t(j)>=0 % normalize theta3 to 0 to 360 degree
            th3t(j) = th3t(j) - 2*pi*(fix(th3t(j)/(2*pi)));
        else
            th3t(j) = th3t(j) - 2*pi*(fix(th3t(j)/(2*pi))-1);
        end
        
        if th4t(j)>=0 % normalize theta4 to 0 to 360 degree
            th4t(j) = th4t(j) - 2*pi*(fix(th4t(j)/(2*pi)));
        else
            th4t(j) = th4t(j) - 2*pi*(fix(th4t(j)/(2*pi))-1);
        end
        
        f1 = R1*cos(th1) + R4*cos(th4t(j)) - R2*cos(th2(i)) - R3*cos(th3t(j));       
        f2 = R1*sin(th1) + R4*sin(th4t(j)) - R2*sin(th2(i)) - R3*sin(th3t(j));
        
        if min([abs(f1) abs(f2)])<1e-4 % set the allowed error for f1 & f2, if it meets the requirement then leave the iteration loop
            break; 
        end      
        df1dth3 = R3*sin(th3t(j));
        df1dth4 = -R4*sin(th4t(j));        
        df2dth3 = -R3*cos(th3t(j));
        df2dth4 = R4*cos(th4t(j));
        M = [df1dth3 df1dth4; df2dth3 df2dth4];
        B = -inv(M)*[f1;f2];
        th3t(j+1) = B(1) + th3t(j);
        th4t(j+1) = B(2) + th4t(j);  
    end
    th3(i) = th3t(j); % assign the iteration result to another variable th3
    th4(i) = th4t(j);
    th30 = th3t(j); % assign the iteration result to the first guess for next theta 3
    th40 = th4t(j);
end

figure;
plot(th2*180/pi,th3*180/pi,th2*180/pi,th4*180/pi)

    