clear all
x0 = [2 1];
x = fsolve(@Fsolve_2D_fcn,x0)