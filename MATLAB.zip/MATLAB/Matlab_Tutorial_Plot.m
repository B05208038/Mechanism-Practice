% create an array variable x from -5 to 5 with the interval 0.01
x = -5:0.01:5;

% create an array variable y1
y1 = 20*cos(3*x);

% create another array varialbe y2
y2 = x.^3 + 2*x.^2 -5*x + 1;

% open a blank figure window (optional)
figure; 

% plot the two curves y1 & y2
plot(x,y1,x,y2)
title('Curve Example')
xlabel('x axis')
ylabel('y axis')
legend('y1','y2')
