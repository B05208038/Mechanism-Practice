clear all

% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
% Plot to function
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 

% x is an array from -10 to 10 with interval 0.001
x = -5:0.001:5; 

% f is a function of x
f = -x.^2 + x.*sin(x) + x + 10; 

% plot 1) the function f, and 2) y=0
figure;
plot(x,f,x,zeros(1,length(x)),'-.')
legend('y = -x^2 + xsin(x) + x + 10','y = 0')

% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
% Newton-Raphson Method
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 

x0 = 4; % inital guess of x, you can try different value 

for i = 1:10000 % loop for iteration
    if i == 1
        x(i) = x0;
    end    
    y(i) = -x(i)^2 + x(i).*sin(x(i)) + x(i) + 10;
    if abs(y(i))<1e-4 % set the allowed error for y, if it meets the requirement then leave the loop
        break; 
    end
    % df(i) is the differentiation of y at x(i)
    df(i) = -2*x(i) + sin(x(i)) + x(i)*cos(x(i)) + 1;
    x(i+1) = -y(i)/df(i) + x(i);    
end

x_sol = x(i)